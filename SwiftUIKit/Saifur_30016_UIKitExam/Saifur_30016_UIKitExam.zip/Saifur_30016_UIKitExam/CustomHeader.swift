//
//  CustomHeader.swift
//  Saifur_30016_UIKitExam
//
//  Created by BJIT on 14/12/22.
//

import UIKit

class CustomHeader: UITableViewHeaderFooterView {

    @IBOutlet weak var backGroundView: UIView!
    
    
    @IBOutlet weak var expenseManager: UILabel!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
